package thesevenitsolutions.com.docshub;

public class common {
    static String getbaseurl(){
        String str = "http://18.223.149.245/doctorshub/public/api/" ;

        return str;
    }
}
